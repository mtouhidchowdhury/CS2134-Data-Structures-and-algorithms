#include<iostream>

using namespace std;

void bar(){
    int arr[25];
}

void foo(){
    cout << "FOO!" << endl;
}


int main({
    cout << "Hi!" << endl;                
}


