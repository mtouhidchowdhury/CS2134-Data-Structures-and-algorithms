int main){
    int potato[25];
}
(
