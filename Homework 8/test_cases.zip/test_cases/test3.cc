#include<iostream>

using namespace std;

int main(){
    cout << "There should be no errors here" << endl;
}
